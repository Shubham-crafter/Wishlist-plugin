<?php
/*
    Plugin Name: Woocommerce wishlist
    Description: Ajax wishlist for WooCommerce Parent Plugin (woocommerce) should be installed and active to use this plugin.
    Author: Pcrafter Technologies
    Version: 1.0
    Author URI: http://enovathemes.com
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/*
    1. Add wishlist to product 
    2. Wishlist table shortcode
    3. Wishlist option in the user profile
    4. Extend rest API for products
    base_url/wp-json/shopping-app/add-product-wishlist?user_id=1&project_id=13
    base_url/wp-json/shopping-app/remove-product-wishlist?project_id=13&user_id=1
    base_url/wp-json/shopping-app/get-product-wishlist?user_id=1

*/
   
   class PcWishList {

public function __construct(){
 
   // Add Js And Css Files For Admin Screen 
        
        add_action('admin_enqueue_scripts', array($this,"Pc_AdminEnqueue"));

        // Add Js And Css Files For Admin Screen 


    //---check woocommerce plugin install or not ------------
    add_action( 'admin_init',array($this,'child_plugin_has_parent_plugin' ));
    //---check woocommerce plugin install or not ------------

     //----- plugin install and activate then this function work --
    add_action('init',array($this,'plugin_init'));
    //----- plugin install and activate then this function work --
    
     //---- All rest Api for  Wish list ---
        //--- Add product Api --
       add_action( 'rest_api_init', array($this,'AddProductIntoWishlist') );
       
       //--- Remove product Api --
       add_action( 'rest_api_init', array($this,'RemoveProductFromWishlist') );
       
       //---fetch product Api--
       add_action( 'rest_api_init', array($this,'GetProductWishlist') );

     //---- All rest Api for  Wish list ---    
      
    
 //--- change icon into header -----
      // add_action('wp_head',array($this,'show_wish_list_button')); 
      //--- change icon into header -----

// ---- enque file in to admin side -----

       

 //Function For Fetch Device type users Using Ajax Start Here
        add_action("wp_ajax_pc_update_menu_option", array($this,"pc_menu_option_update"));
        //Function For Fetch Device type users Using Ajax End Here

}



// ------------ update menu option in admin side ------

 public function pc_menu_option_update(){

    $meta_value = $_POST["meta_value"] ;

if($meta_value == null ){
    $meta_value   = 0 ;
}
 $add =  update_option( 'wish-list-menu-active', $meta_value ,'' );

           echo json_encode($meta_value);
        
           die;
        
    }
 
// ------------ update menu option in admin side ------




// Add Js And Css Files For Admin Screen 

public function Pc_AdminEnqueue(){
        // Enqueue Script Here
        wp_enqueue_script('jquery');
        
        if(isset($_GET['page'])){
        $plugin_page = $_GET['page'];
        }else{
            $plugin_page='';
        }
         // Enqueue Styles Here
         
        // Check If Page Is Pc Pusher Start Here
        if($plugin_page == 'wish-list'){
          
        wp_enqueue_style('wishlist_style_css', plugins_url('css/admin_style.css', __FILE__), null, '1.0');
       
       // wp_enqueue_script('wishlist_admin_page', plugins_url('js/admin_index.js', __FILE__), array('jquery'), '1.0');

       //  wp_localize_script( 'wishlist_admin_page', 'pcAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));         

        
        wp_enqueue_script('firebase_push_notification_index_js', plugins_url('js/admin_index.js', __FILE__), array('jquery'), '1.0');

        wp_localize_script( 'firebase_push_notification_index_js', 'pcAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));    


        }
      }

//-------this function check woocommerce plugin active or not -----
function child_plugin_has_parent_plugin() {
    if ( is_admin() && current_user_can( 'activate_plugins' ) &&  !is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
        add_action( 'admin_notices',array($this,'child_plugin_notice' ));

        deactivate_plugins( plugin_basename( __FILE__ ) ); 

        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }
    }
}
//-------this function check woocommerce plugin active or not -----


//-------Show error when plugin activate -----
function child_plugin_notice(){
    ?><div class="error"><p>Sorry, but woocommerce Wishlist Plugin requires the woocommerce plugin to be installed and active.</p></div><?php
}
//-------Show error when plugin activate -----


//-------- check the plugin active or not ------
function plugin_init(){
    if (class_exists("Woocommerce")) {  //-- check plugin active or not --
        
 

           // ------- add wishlist menu into header ---------
     add_filter( 'wp_nav_menu_items', 'add_menu_cart', 10, 2 );
    
    function add_menu_cart( $items, $args ) {

    	      $color1 =  get_option( 'wish-list-primary-color', false );
            $color2 =  get_option( 'wish-list-secondary-color', false );
        $menu_option =  get_option( 'wish-list-menu-active', false );
            
          
          if($color1 ==''){
            $color1 ='#ff0000';
          }
          
          if($color2 ==''){
           $color2 ='#fff000'; 
          }
          
         $current_user = wp_get_current_user();
         $current_user_wishlist = get_user_meta( $current_user->ID, 'wishlist',true);
          
            
          if($current_user_wishlist){
            $heart_icon ='<i class="fa fa-heart wishlist-menu-filled-class" aria-hidden="true"></i>';
          }else{
            $heart_icon ='<i class="fa fa-heart-o wishlist-menu-blank-class" aria-hidden="true"></i>'; 
          }


    // if ( 'primary' === $args->theme_location ) {
        global $woocommerce;
       
        wp_get_current_user();
        $myaccount_page_url = get_permalink( woocommerce_get_page_id( 'myaccount' ) );
        
        // $items .= '<li id="wish_list_menu_id" class="main-menu-item cart_right">
        //     <div class="cart_dropdown_widget"><a href="wish-list" class="heart-icon-class"></a></div>
        // </li>';
       $wish_url = site_url().'/wish-list/';
 
 if( 'primary' === $args->theme_location && $menu_option == 0 || empty($menu_option)){
$items .='<div id="wish_list_menu_id" class="main-menu-item cart_right">
     <!-- set primary and secondary color -->
     <style>         
       .fa-heart{ color: ' .$color1. '; }
       .fa-heart-o{ color: ' .$color2 .'; }
       .button{background-color: '.$color1.';}
       </style>
            <div class="cart_dropdown_widget"><a href="'. $wish_url .'" class="heart-icon-class" title="Wish-list">
            '. $heart_icon .'
            </a>
            </div>

          <div class="wish-list-dropdown-content">
          
          <div class="wish-list-main-content">
            <p id="no-pro-in-wish"> No products in the wish list.</p>
            <ul class="woocommerce-mini-wishlist wish_list product_list_widget wish_list_ul" id="menu-ul-id">
                        
           </ul>
           </div>
          
           <div class="wish-list-btn-content">
            <p class="woocommerce-mini-buttons buttons" style="margin: 10px;">
                <a href="'. $wish_url .'" class="button wc-forward">View</a></p>
           </div>

          </div>  
          
        </div>';
}else{

  $items .='<style>         
       .fa-heart{ color: ' .$color1. '; }
       .fa-heart-o{ color: ' .$color2 .'; }
       .button{background-color: '.$color1.';}
       </style>';
}
         
    
        return $items;

    // }
}

// ------- add wishlist menu into header ---------





          //------ add script and style file function here ---
        function wishlist_plugin_scripts_styles(){  
            
            //----custom style add ---
            wp_enqueue_style( 'wishlist-style', plugins_url('/css/style.css', __FILE__ ), array(), '1.0.0' );
           //----custom style add ---
            
            //----font-awesome style add ---
            wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css' );
            //----font-awesome style add ---
            
            //----Custom script add ---
            wp_enqueue_script( 'main', plugins_url('/js/main.js', __FILE__ ), array('jquery'), '', true);
            //----Custom script add ---

              //----sweet alert shoe in popups
           
           wp_enqueue_script('sweet-alert-js-file',"https://cdn.jsdelivr.net/npm/sweetalert2@9",array('jquery'));

               //----sweet alert shoe in popups
            
            wp_localize_script(
                'main',
                'opt',
                array(
                    'ajaxUrl'        => admin_url('admin-ajax.php'),
                    'ajaxPost'       => admin_url('admin-post.php'),
                    'restUrl'        => rest_url('wp/v2/product'),
                    'shopName'       => sanitize_title_with_dashes(sanitize_title_with_dashes(get_bloginfo('name'))),
                    'inWishlist'     => esc_html__("Already in wishlist","text-domain"),
                    'removeWishlist' => esc_html__("Remove from wishlist","text-domain"),
                    'buttonText'     => esc_html__("Details","text-domain"),
                    'error'          => esc_html__("Something went wrong, could not add to wishlist","text-domain"),
                    'noWishlist'     => esc_html__("No wishlist found","text-domain"),
                )
            );
        }
        //------ add script and style file function here ---
        add_action( 'wp_enqueue_scripts', 'wishlist_plugin_scripts_styles' );
        //------ add script and style file function here ---


 //Add Wish List page on activation

  //-- create page when activation 
     $new_page_title = 'Wish List';
        $new_page_content = '[wishlist]';
        $new_page_template ='';  //wishlist_template.php
        $page_check = get_page_by_title($new_page_title);
        $new_page = array(
                'post_type' => 'page',
                'post_title' => $new_page_title,
                'post_content' => $new_page_content,
                'post_status' => 'publish',
                'post_author' => 1,
        );
            
        if(!isset($page_check->ID)){
                $new_page_id = wp_insert_post($new_page);
                if(!empty($new_page_template)){
                        update_post_meta($new_page_id, '_wp_page_template', $new_page_template);
                }
        }
        //-- create page when activation 

//end install_events_pg function to add page to wp on plugin activation



   //------ add page into admin side
 add_action('admin_menu', 'my_menu_pages');
     //------ add page into admin side


//----- add menu page into admin side ---
function my_menu_pages(){
    add_menu_page('Wish List page', 'Wish list Page', 'manage_options', 'wish-list', 'my_menu_output' );
    
}
//----- add menu page into admin side ---


//----- View for admin page ---
function my_menu_output(){

  if($_POST['wish-list-primary-color']){
    $value = $_POST['wish-list-primary-color'];
 $add =  update_option( 'wish-list-primary-color', $value , '#ff0000', 'yes' );

  }

  if($_POST['wish-list-secondary-color']){
  $value = $_POST['wish-list-secondary-color'];
 $add = update_option( 'wish-list-secondary-color', $value , '#ff0000', 'yes' );
  }
if($add){
    echo '<h3 style="color: #4bb543; text-align:center;"> Color value insert successful. </h3>';
}

            $color1 =  get_option( 'wish-list-primary-color', false );
            $color2 =  get_option( 'wish-list-secondary-color', false );
             
            $menu_active =  get_option( 'wish-list-menu-active', false ); 

            if($menu_active == 0 || empty($menu_active)){
              
                   $checked ='checked';
              $value = 0;
            }else{

          $checked ='';
          $value = 1  ;

            }


 echo "<h1> Set Wish list icon colour value</h1>";
 echo '<form  method="POST" action="" class="form-group"> 
          <label><b>Primary color &nbsp;&nbsp;&nbsp;</b></label>
        <input type="color" placeholder="add primary color code Here" name="wish-list-primary-color" class="form-control" style="width: 10%; height:30px;" required value="'.$color1.'"><br><br>
        <label><b>Secondary color</b></label>
        <input type="color" placeholder="add secodary color code Here" name="wish-list-secondary-color" class="form-control" style=" width: 10%; height:30px;" required  value="'.$color2.'"> <br><br>
     <input type="submit" value="submit" style="background-color: #4bb543;width: 10%;height: 40px;color: #fff;font-size: 18px;">
        </form>';

  echo "<br><br><br>";      
  echo "<h1>Icon hide and show in menu</h1>";
  echo '<label class="switch">
  <input type="checkbox" '. $checked .' id="menu-check-box-id" value="'.$value.'">
  <span class="slider round"></span>
  </label>';

}

//----- View for admin page---

  
    //---- remove page from all page list ---
    add_filter( 'parse_query', 'exclude_pages_from_admin' );
    
  
    //------ remove page from all page list in admin side ---
function exclude_pages_from_admin($query) {
    global $pagenow,$post_type;
    if (is_admin() && $pagenow=='edit.php' && $post_type =='page') {

    $page = get_page_by_title( 'Wish List', $post_type = 'page' );    
    $page_id = $page->ID;

        $query->query_vars['post__not_in'] = array($page_id);
    }
}
  //------ remove page from all page list in admin side function End Here ---    

          
        // Get current user data
        function fetch_user_data() {
            if (is_user_logged_in()){
                $current_user = wp_get_current_user();
                $current_user_wishlist = get_user_meta( $current_user->ID, 'wishlist',true);
    			echo json_encode(array('user_id' => $current_user->ID,'wishlist' => $current_user_wishlist));
            }
            die();
        }

        //-----fetch user data by Ajax call ----
        add_action( 'wp_ajax_fetch_user_data', 'fetch_user_data' );
        add_action( 'wp_ajax_nopriv_fetch_user_data', 'fetch_user_data' );
       //-----fetch user data by Ajax call Action Hook ----


        // Add wishlist to product

        add_action('woocommerce_before_shop_loop_item_title','wishlist_toggle',15);
        add_action('woocommerce_single_product_summary','wishlist_toggle',25);
        
        //------ Add and remove product to wishlist  and add icon
        function wishlist_toggle(){

            global $product;
            $product_cart_id = WC()->cart->generate_cart_id(esc_attr($product->get_id()));
            $in_cart = WC()->cart->find_product_in_cart( $product_cart_id);
            
            if(!$in_cart){
             $in_cart = 1 ;
            }
            
            echo '<span class="wishlist-title">'.esc_attr__("Add to wishlist","text-domain").'</span><a id="wishlist-toggle-'.esc_attr($product->get_id()).'" class="wishlist-toggle" data-cart="'. $in_cart.'" data-product="'.esc_attr($product->get_id()).'" href="#" title="'.esc_attr__("Add to wishlist","text-domain").'"><i class="fa fa-heart-o" aria-hidden="true"></i></a>';
        }
       //------ Add and remove product to wishlist  and add icon


        // Wishlist option in the user profile
        add_action( 'show_user_profile', 'wishlist_user_profile_field' );
        add_action( 'edit_user_profile', 'wishlist_user_profile_field' );

        //--- get user detail and add in to wish list
        function wishlist_user_profile_field( $user ) { ?>
            <table class="form-table wishlist-data">
                <tr>
                    <th><?php echo esc_attr__("Wishlist","text-domain"); ?></th>
                    <td>
                        <input type="text" name="wishlist" id="wishlist" value="<?php echo esc_attr( get_the_author_meta( 'wishlist', $user->ID ) ); ?>" class="regular-text" />
                    </td>
                </tr>
            </table>
        <?php }
        //--- get user detail and add in to wish list



        //--- Save and update user detail and Wish List value  
        add_action( 'personal_options_update', 'save_wishlist_user_profile_field' );
        add_action( 'edit_user_profile_update', 'save_wishlist_user_profile_field' );
       //--- Save and update user detail and Wish List value  

       //--- Save and update user value function start Here -  
        function save_wishlist_user_profile_field( $user_id ) {
            
            if ( !current_user_can( 'edit_user', $user_id ) ) {   //--check user_id present here or not 
                return false;
            }

            update_user_meta( $user_id, 'wishlist', $_POST['wishlist'] );
        }
        //--- Save and update user value function start Here -



         //--------  update wishlist using ajax function Start Here
        function update_wishlist_ajax(){
            if (isset($_POST["user_id"]) && !empty($_POST["user_id"])) {
                $user_id   = $_POST["user_id"];
                $user_obj = get_user_by('id', $user_id);
                if (!is_wp_error($user_obj) && is_object($user_obj)) {
                    update_user_meta( $user_id, 'wishlist', $_POST["wishlist"]);
                }
            }
            die();
        }
        //--------  update wishlist using ajax function Start Here

        //---- Ajax function for get and update user wishlist start Here 
        add_action('admin_post_nopriv_user_wishlist_update', 'update_wishlist_ajax');
        add_action('admin_post_user_wishlist_update', 'update_wishlist_ajax');
       //---- Ajax function for get and update user wishlist start Here 


        // Wishlist table shortcode for show on front end
        add_shortcode('wishlist', 'wishlist');
 

 // Wishlist table shortcode function for show on front end
        function wishlist( $atts, $content = null ) {

            extract(shortcode_atts(array(), $atts));
            $url = get_site_url();
            return '<table class="wishlist-table loading">
                    <input type="hidden" value="'.$url.'" id="base-url-id" >
                        <tr>
                            <th><!-- Left for image --></th>
                            <th>'.esc_html__("Name","text-domain").'</th>
                            <th>'.esc_html__("Price","text-domain").'</th>
                            <th>'.esc_html__("Stock","text-domain").'</th>
                            <th><!-- Left for button --></th>
                            <th><!-- Left for button --></th>
                        </tr>
                    </table>';

        }

        // Wishlist table shortcode function for show on front end

        // Extend REST  function for get value and show into shortcode (wishlist) Start here ---
        function rest_register_fields(){

            register_rest_field('product',
                'price',
                array(
                    'get_callback'    => 'rest_price',
                    'update_callback' => null,
                    'schema'          => null
                )
            );

            register_rest_field('product',
                'stock',
                array(
                    'get_callback'    => 'rest_stock',
                    'update_callback' => null,
                    'schema'          => null
                )
            );

            register_rest_field('product',
                'image',
                array(
                    'get_callback'    => 'rest_img',
                    'update_callback' => null,
                    'schema'          => null
                )
            );
        }
        //------ hooks for register rest route--------
        add_action('rest_api_init','rest_register_fields');
        //------ hooks for register rest route--------

        
        function rest_price($object,$field_name,$request){

            global $product;

            $id = $product->get_id();

            if ($id == $object['id']) {
                return $product->get_price();
            }

        }

        function rest_stock($object,$field_name,$request){

            global $product;

            $id = $product->get_id();

            if ($id == $object['id']) {
                return $product->get_stock_status();
            }

        }

        function rest_img($object,$field_name,$request){

            global $product;

            $id = $product->get_id();

            if ($id == $object['id']) {
                return $product->get_image();
            }

        }

        function maximum_api_filter($query_params) {
            $query_params['per_page']["maximum"]=100;
            return $query_params;
        }
        add_filter('rest_product_collection_params', 'maximum_api_filter');
    }
    //----class_exists("Woocommerce") End Here----

}
//-------- check the plugin active or not function End Here------


//------------------------------Rest Api All Function Start Here ------------

//--- Add into wishlist---
public function AddProductIntoWishlist(){
            register_rest_route('shopping-app', 'add-product-wishlist', array(
                'methods' => 'POST,GET',   
                'callback' => array($this,'pc_add_product_into_wishlist_callback'),
            )
            );
        }
//---Add into wishlist -- 

//--- Add into wishlist---
public function RemoveProductFromWishlist(){
            register_rest_route('shopping-app', 'remove-product-wishlist', array(
                'methods' => 'POST,GET',   
                'callback' => array($this,'pc_remove_product_from_wishlist_callback'),
            )
            );
        }
//---Add into wishlist -- 

//--- Add into wishlist---
public function GetProductWishlist(){
            register_rest_route('shopping-app', 'get-product-wishlist', array(
                'methods' => 'POST,GET',   
                'callback' => array($this,'pc_get_product_wishlist_callback'),
            )
            );
        }
//---Add into wishlist -- 

    // Add product into wishlist call_back function ---
        public function pc_add_product_into_wishlist_callback(){
           
              if (!isset($_REQUEST["project_id"]) && empty($_REQUEST["project_id"])) {
           $response = array('data'=>array('error'=>'required error') ,'message'=>'project_id is required','status'=>400);         
                return rest_ensure_response($response); 
                die();
              }

              if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
                $user_id   = $_REQUEST["user_id"];
                $user_obj = get_user_by('id', $user_id);

                if (!is_wp_error($user_obj) && is_object($user_obj)) {

                   $wish_list =  get_user_meta( $user_id,'wishlist',false );
                    if(count($wish_list)> 0){
                         
                         $wish_list_array = explode(",",$wish_list[0]);
                         
                         foreach($wish_list_array as $key=>$value){
                               if($value == $_REQUEST['project_id']){
                           
                           $response = array('data'=>array('success'=>'false') ,'message'=>'product already add in to wishlist','status'=>400);         
                return rest_ensure_response($response);                
                                 break;     
                         }

                         }

                        $products = $wish_list[0].','.$_REQUEST['project_id'];
                        
                      $add_wishlist = update_user_meta( $user_id, 'wishlist', $products);

                    }else{                    
                    
                    $add_wishlist = update_user_meta( $user_id, 'wishlist', $_REQUEST['project_id']);
                
                }
                 
                 if($add_wishlist){
                  $response = array('data'=>array('success'=>'true') ,'message'=>'product add into wishlist successful','status'=>200);         
                return rest_ensure_response($response); 

                 }else{
                    $response = array('data'=>array('success'=>'failed') ,'message'=>'product add into wishlist failed','status'=>400);         
                return rest_ensure_response($response); 

                 }

                }else{
                   $response = array('data'=>array('error'=>'required error') ,'message'=>'invalid user_id','status'=>400);         
                return rest_ensure_response($response); 

                }
            }else{
                $response = array('data'=>array('error'=>'required error') ,'message'=>'user_id is required','status'=>400);         
                return rest_ensure_response($response); 
            }
            
        }
    // Add product into wishlist call_back function ---

    //--- remove product from wish list call back function start here ------
    public function pc_remove_product_from_wishlist_callback(){
      if (!isset($_REQUEST["project_id"]) && empty($_REQUEST["project_id"])) {
           $response = array('data'=>array('error'=>'required error') ,'message'=>'project_id is required','status'=>400);         
                return rest_ensure_response($response); 
                die();
              }

              if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
                $user_id   = $_REQUEST["user_id"];
                $user_obj = get_user_by('id', $user_id);

                if (!is_wp_error($user_obj) && is_object($user_obj)) {

                   $wish_list =  get_user_meta( $user_id,'wishlist',false );
                    if(count($wish_list)> 0){
                         
                         $wish_list_array = explode(",",$wish_list[0]);
                         
                         foreach($wish_list_array as $key=>$value){
                           
                               if($value == $_REQUEST['project_id']){
                           
                               unset($wish_list_array[$key]);
                               break;     
                           }
                         
                         }

                              
                        $products =  implode(",",$wish_list_array);
                        
                      $remove_wishlist = update_user_meta( $user_id, 'wishlist', $products);

                    }
                 
                 if($remove_wishlist){
                  $response = array('data'=>array('success'=>'true') ,'message'=>'product remove into wishlist successful','status'=>200);         
                return rest_ensure_response($response); 

                 }else{
                    $response = array('data'=>array('success'=>'failed') ,'message'=>'product remove into wishlist failed','status'=>400);         
                return rest_ensure_response($response); 

                 }

                }else{
                   $response = array('data'=>array('error'=>'required error') ,'message'=>'invalid user_id','status'=>400);         
                return rest_ensure_response($response); 

                }
            }else{
                $response = array('data'=>array('error'=>'required error') ,'message'=>'user_id is required','status'=>400);         
                return rest_ensure_response($response); 
            }
    }
     //--- remove product from wish list call back function End here ------

//--- remove product from wish list call back function start here ------
    public function pc_get_product_wishlist_callback(){
    if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
                $user_id   = $_REQUEST["user_id"];
                $user_obj = get_user_by('id', $user_id);

                if (!is_wp_error($user_obj) && is_object($user_obj)) {

                   $wish_list =  get_user_meta( $user_id,'wishlist',false );
                    if(count($wish_list)> 0){
                    $wish_list_array = explode(",",$wish_list[0]);
                      $data = array();

                      foreach ($wish_list_array as $key => $value) {
                        $product = wc_get_product( $value );
            
            $data[$key]['id'] = $product->get_id(); 
            $data[$key]['title'] = $product->get_title(); 
            $data[$key]['slug'] = $product->get_slug(); 
            $data[$key]['permalink'] = $product->get_permalink(); 
            $data[$key]['date_created'] = $product->get_date_created(); 
            $data[$key]['date_modified'] = $product->get_date_modified(); 
            $data[$key]['type'] = $product->get_type(); 
            $data[$key]['status'] = $product->get_status(); 
            $data[$key]['description'] = $product->get_description(); 
            $data[$key]['short_description'] = $product->get_short_description(); 
            $data[$key]['sku'] = $product->get_sku(); 
            $data[$key]['date_on_sale_from'] = $product->get_date_on_sale_from(); 
            $data[$key]['date_on_sale_to'] = $product->get_date_on_sale_to(); 
            $data[$key]['price'] = $product->get_price(); 
            $data[$key]['regular_price'] = $product->get_regular_price(); 
            $data[$key]['sale_price'] = $product->get_sale_price(); 
      // $data[$key]['on_sale'] = $product->get_on_sale(); 
      // $data[$key]['purchasable'] = $product->get_purchasable(); 
            $data[$key]['stock_status'] = $product->get_stock_status(); 
            $data[$key]['reviews_allowed'] = $product->get_reviews_allowed(); 
            $data[$key]['average_rating'] = $product->get_average_rating(); 
            $data[$key]['rating_count'] = $product->get_rating_count(); 
    // $data[$key]['related_ids'] = $product->get_related_ids(); 

            $data[$key]['parent_id'] = $product->get_parent_id(); 
            $data[$key]['categories'] = $product->get_categories(); 
            $data[$key]['tags'] = $product->get_tags(); 
    // $data[$key]['images'] = $product->get_image(); 
            if(wp_get_attachment_url( $product->get_image_id())){
              $data[$key]['images'] = wp_get_attachment_url( $product->get_image_id()); 
            }else{
              $data[$key]['images'] =''; 
            }
            $data[$key]['attributes'] = $product->get_attributes(); 
    // $data[$key]['variations'] = $product->get_variations(); 
    // $data[$key]['grouped_products'] = $product->get_grouped_product(); 
            $data[$key]['default_attributes'] = $product->get_default_attributes(); 
            $data[$key]['menu_order'] = $product->get_menu_order(); 
            $data[$key]['meta_data'] = $product->get_meta_data(); 

                      }
                    
                    $response = array('data'=>$data ,'message'=>'wish list product fetch successfull','status'=>200);         
                return rest_ensure_response($response);          
                    }else{
                    $response = array('data'=>array('data'=>array()) ,'message'=>'no any product into wish list ','status'=>200);         
                return rest_ensure_response($response); 
                    }
    }
 }else{
    $response = array('data'=>array('error'=>'required error') ,'message'=>'user_id is required','status'=>400);         
                return rest_ensure_response($response); 
 }
}
     //--- remove product from wish list call back function End here ------




} //----- class End Here -----



 global $pcWishListObj;

 $pcWishListObj = new PcWishList;
