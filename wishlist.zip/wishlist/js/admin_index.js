// jQuery(document).on('change','#menu-check-box-id',function(){
//        var val = jQuery(this).val();
     
//      if(val == 0){
//      var main_val = 1;
//     }else {
//     var main_val = 0;
//    }
//      // console.log(pcAjax.ajaxurl);
//      jQuery.ajax({
//             method:"POST",
//             url:pcAjax.ajaxurl,
//             // dataType: 'json',
//             data:{action:"update_menu_option",meta_value:main_val},
//             success:function(res){
//                 console.log(res);
//             }
//         });

        
//     });


jQuery(document).on('change','#menu-check-box-id',function(){
        var val = jQuery(this).val();

         if(val == 0){
      var main_val = 1;
     }else {
     var main_val = 0;
    }
    // alert(main_val);
        jQuery.ajax({
            method:"POST",
            url:pcAjax.ajaxurl,
            dataType: 'json',
            data:{action:"pc_update_menu_option",meta_value:main_val},
            success:function(res){
            // alert(res);
            }
        });

        
    });