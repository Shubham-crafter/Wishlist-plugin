(function($){

    "use strict";

    /*
        1. Add product to wishlist
        2. Display wishlist items in the table
        3. Remove product from the wishlist

    */

    Array.prototype.unique = function() {
      return this.filter(function (value, index, self) {
        return self.indexOf(value) === index;
      });
    }

    function isInArray(value, array) {return array.indexOf(value) > -1;}

    function onWishlistComplete(target, title){
        setTimeout(function(){
            target
            .removeClass('loading')
            .addClass('wishlist-remove')
            .attr('title',title);
        },800);
    }

    function highlightWishlist(wishlist,title){
        $('.wishlist-toggle').each(function(){
            var $this = $(this);
            var currentProduct = $this.data('product');
            currentProduct = currentProduct.toString();
            if (isInArray(currentProduct,wishlist)) {
                $this.addClass('wishlist-remove').attr('title',title);

                $this.html('<i class="fa fa-heart" aria-hidden="true"></i>');
            }
        });
    }

    var shopName   = opt.shopName+'-wishlist',
        inWishlist = opt.inWishlist,
        restUrl    = opt.restUrl,
        wishlist   = new Array,
        ls         = sessionStorage.getItem(shopName),
        loggedIn   = ($('body').hasClass('logged-in')) ? true : false,
        userData   = '';

    if(loggedIn) {
        // Fetch current user data
        $.ajax({
            type: 'POST',
            url: opt.ajaxUrl,
            data: {
                'action' : 'fetch_user_data',
                'dataType': 'json'
            },
            success:function(data) {
                userData = JSON.parse(data);
                if (typeof(userData['wishlist']) != 'undefined' && userData['wishlist'] != null && userData['wishlist'] != "") {

                    var userWishlist = userData['wishlist'];
                    userWishlist = userWishlist.split(',');

                    if (wishlist.length) {
                        wishlist =  wishlist.concat(userWishlist);

                        $.ajax({
                            type: 'POST',
                            url:opt.ajaxPost,
                            data:{
                                action:'user_wishlist_update',
                                user_id :userData['user_id'],
                                wishlist :wishlist.join(','),
                            }
                        });

                    } else {
                        wishlist =  userWishlist;
                    }

                    wishlist = wishlist.unique();

                    highlightWishlist(wishlist,inWishlist);
                    sessionStorage.removeItem(shopName);

                } else {
                    if (typeof(ls) != 'undefined' && ls != null) {
                        ls = ls.split(',');
                        ls = ls.unique();
                        wishlist = ls;
                    }

                    $.ajax({
                        type: 'POST',
                        url:opt.ajaxPost,
                        data:{
                            action:'user_wishlist_update',
                            user_id :userData['user_id'],
                            wishlist :wishlist.join(','),
                        }
                    })
                    .done(function(response) {
                        highlightWishlist(wishlist,inWishlist);
                        sessionStorage.removeItem(shopName);
                    });
                }
            },
            error: function(){
                console.log('No user data returned');
            }
        });
    } else {
        // if (typeof(ls) != 'undefined' && ls != null) {
        //     ls = ls.split(',');
        //     ls = ls.unique();
        //     wishlist = ls;
        // }
        // alert('please Login First11');
    }

    $('.wishlist-toggle').each(function(){

        var $this = $(this);

        var currentProduct = $this.data('product');

        currentProduct = currentProduct.toString();

        if (!loggedIn && isInArray(currentProduct,wishlist)) {
            $this.addClass('wishlist-remove').attr('title',inWishlist);

        }

        $(this).on('click',function(e){
            e.preventDefault();
            var cart_val = $this.data('cart');
            // console.log(cart_val);
            if(cart_val != 1){
                // alert('This Product already add in to  cart');
    Swal.fire({

                    html:"<h4>This Product already add in to  cart</h4>",

                    showCancelButton: true,

                    confirmButtonColor: '#3085d6',

                    cancelButtonColor: '#d33',

                    });


                return false;

            }

            if (!$this.hasClass('wishlist-remove') && !$this.hasClass('loading')) {

                // $this.addClass('loading');
                wishlist.push(currentProduct);
                wishlist = wishlist.unique();
                 
                if (loggedIn) {
                    // get user ID
                    if (userData['user_id']) {
                        $.ajax({
                            type: 'POST',
                            url:opt.ajaxPost,
                            data:{
                                action:'user_wishlist_update',
                                user_id :userData['user_id'],
                                wishlist :wishlist.join(','),
                            }
                        })
                        .done(function(response) {
                            onWishlistComplete($this, inWishlist);
                        })
                        .fail(function(data) {
                            alert(opt.error);
                        });
                    }
            
            //-----call this function for menu 
            $this.html('<i class="fa fa-heart" aria-hidden="true"></i>'); 
           
            wishlist_menu(wishlist);
            
             add_wish_list_menu_item_show(wishlist,currentProduct);
            
                } else {

                    // sessionStorage.setItem(shopName, wishlist.toString());
                    // onWishlistComplete($this, inWishlist);
                    // alert('please Login First..');  //--22

                    
                    Swal.fire({

                    html:"<h4>please Login First.</h4>",

                    showCancelButton: true,

                    confirmButtonColor: '#3085d6',

                    cancelButtonColor: '#d33',

                    });


                }
            
            }


        });
    });

    setTimeout(function(){

        if (wishlist.length) {

            restUrl += '?include='+wishlist.join(',');
            restUrl += '&per_page='+wishlist.length;

            $.ajax({
                dataType: 'json',
                url:restUrl
            })
            .done(function(response){
                $('.wishlist-table').each(function(){
                    var $this = $(this);
                    var url = $('#base-url-id').val();
                    
                    $.each(response,function(index,object){
                        $this.append('<tr data-product="'+object.id+'"><td class="wish-list-img-td"><a class="wishlist-remove-btn" href="#" title="'+opt.removeWishlist+'"></a>'+object.image+'</td><td>'+object.title["rendered"]+'</td><td>'+object.price+'</td><td>'+object.stock+'</td><td><a class="details" href="'+object.link+'">'+opt.buttonText+'</a></td><td class="wish-list-add-to-cart" id="wish-list-cart-btn-'+object.id+'"><a href="'+url+'/shop/?add-to-cart='+object.id+'" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" id="wish-list-add-to-cart-btn" data-product_id="'+object.id+'" data-product_sku="" aria-label="Add “beg” to your cart" rel="nofollow">Add to cart</a></td></tr>');
                    });
                });
            })
            .fail(function(response){
                alert(opt.noWishlist);
            })
            .always(function(response){
                $('.wishlist-table').each(function(){
                    $(this).removeClass('loading');
                });
            });

        } else {
            $('.wishlist-table').each(function(){
                $(this).removeClass('loading');
            });
        }
      
      //-----call this function for menu item
       // wishlist_menu(wishlist);
       wish_list_menu_item_show(wishlist);

    },1000);

     ///---- this is use for remove product from wish list table 
    $(document).on('click', '.wishlist-remove-btn', function(){

        var $this = $(this);

        $this.closest('table').addClass('loading');

        var currentProduct = $this.closest('tr').data('product');

        wishlist = [];
         
        $this.closest('table').find('tr').each(function(){
            
            if ($(this).data('product') != $this.closest('tr').data('product')) {

                wishlist.push($(this).data('product'));

                if (loggedIn) {

                    // get user ID
                    if (userData['user_id']) {
                        $.ajax({
                            type: 'POST',
                            url:opt.ajaxPost,
                            data:{
                                action:'user_wishlist_update',
                                user_id :userData['user_id'],
                                wishlist :wishlist.join(','),
                            }
                        })
                        .done(function(response) {
                            $this.closest('table').removeClass('loading');
                            $this.closest('tr').remove();
                        })
                        .fail(function(data) {
                            alert(opt.error);
                        });
                    }
                } else {
                    // sessionStorage.setItem(shopName, wishlist.toString());
                    // setTimeout(function(){
                    //     $this.closest('table').removeClass('loading');
                    //     $this.closest('tr').remove();
                    // },500);
                    // alert('please Login First...');

                    Swal.fire({

                    html:"<h4>please Login First.</h4>",

                    showCancelButton: true,

                    confirmButtonColor: '#3085d6',

                    cancelButtonColor: '#d33',

                    });
                }
            }else{
                 $('.pop-li-'+currentProduct).css('display','none');
            }

        });

        //-----call this function for menu 
       wishlist_menu(wishlist);
       
        if(wishlist.length == 0 ){
          $('#no-pro-in-wish').css('display','block');
           $('.wish_list_ul').css('display','none');
           $('.wish-list-btn-content').css('display','none');
      }
       
       // all item hide from wishlist menu ---
       if(wishlist.length == 1){
           $.each(wishlist,function(index1,value1){
           if(typeof value1 == 'undefined'){
         
           $('#no-pro-in-wish').css('display','block');
           $('.wish_list_ul').css('display','none');
           $('.wish-list-btn-content').css('display','none');
            
           }

           });
 }
    });


$(document).on('click', '.wishlist-remove', function(){

 var $this = $(this);
 $this.removeClass('wishlist-remove');
 $this.addClass('loading');
 $this.html('<i class="fa fa-heart-o" aria-hidden="true"></i>');
 wishlist = [];
 
                          
$('.wishlist-toggle').each(function(){

        var $this_val = $(this);

        var currentProduct = $this_val.data('product');
        
        var class_name =  $this_val.attr('class');
        
        if(class_name =='wishlist-toggle wishlist-remove'){
        wishlist.push($(this).data('product'));
        }else{
            $('.pop-li-'+currentProduct).css('display','none');
        }

});
   

                if (loggedIn) {

                    // get user ID
                    if (userData['user_id']) {
                        $.ajax({
                            type: 'POST',
                            url:opt.ajaxPost,
                            data:{
                                action:'user_wishlist_update',
                                user_id :userData['user_id'],
                                wishlist :wishlist.join(','),
                            }
                        })
                        .done(function(response) {
                            $this.removeClass('loading');
                            $this.attr('title','Add to wishlist');
                        })
                        .fail(function(data) {
                            alert(opt.error);
                        });
                    }
                } else {
                    // sessionStorage.setItem(shopName, wishlist.toString());
                    // setTimeout(function(){
                    //     $this.removeClass('loading');
                    // },500);
                    // alert('please Login First');
             Swal.fire({

                    html:"<h4>please Login First.</h4>",

                    showCancelButton: true,

                    confirmButtonColor: '#3085d6',

                    cancelButtonColor: '#d33',

                    });


                }
       
       //-----call this function for menu 
       wishlist_menu(wishlist);
      
      if(wishlist.length == 0){
          $('#no-pro-in-wish').css('display','block');
           $('.wish_list_ul').css('display','none');
           $('.wish-list-btn-content').css('display','none');
      }



});

//----------- Add to cart button in wish list page --------
 $(document).on('click','#wish-list-add-to-cart-btn',function(){
  var id = $(this).attr('data-product_id');

var $this = $(this);

        $this.closest('table').addClass('loading');

        wishlist = [];
         
        $this.closest('table').find('tr').each(function(){
            // console.log($(this).data('product'));
            if ($(this).data('product') != id && $(this).data('product') !='undefined') {
                
                wishlist.push($(this).data('product'));
                 
                if (loggedIn) {

                    // get user ID
                    if (userData['user_id']) {
                        $.ajax({
                            type: 'POST',
                            url:opt.ajaxPost,
                            data:{
                                action:'user_wishlist_update',
                                user_id :userData['user_id'],
                                wishlist :wishlist.join(','),
                            }
                        })
                        .done(function(response) {

                            $this.closest('table').removeClass('loading');
                            $this.closest('tr').remove();

                        })
                        .fail(function(data) {
                            alert(opt.error);
                        });
                    }
                } else {
                    // sessionStorage.setItem(shopName, wishlist.toString());
                    // setTimeout(function(){
                    //     $this.closest('table').removeClass('loading');
                    //     $this.closest('tr').remove();
                    // },500);
                    // alert('please Login First');

                    Swal.fire({

                    html:"<h4>please Login First.</h4>",

                    showCancelButton: true,

                    confirmButtonColor: '#3085d6',

                    cancelButtonColor: '#d33',

                    });
                }
            }

        
   });
        //-------- call wish list shoe in popup and menu colour function

    wishlist_menu(wishlist.length  - 1);              
    $('.pop-li-'+id).css('display','none');  
    remove_wish_list_menu_item_show(wishlist);    
    
    
});
//----------- Add to cart button in wish list page --------


//-------wish list menu color change using this function 

function wishlist_menu(wishlist){

   if(wishlist.length == 0 || wishlist == 0){
    
   $('.heart-icon-class').html('<i class="fa fa-heart-o wishlist-menu-blank-class" aria-hidden="true"></i>');
    console.log(wishlist);
    console.log('blank yessss wishlist');
    // $('.wishlist-menu-filled-class').css('display','none');
    // $('.wishlist-menu-blank-class').css('display','block');
   }else{
     
   $('.heart-icon-class').html('<i class="fa fa-heart wishlist-menu-filled-class" aria-hidden="true"></i>');
     
console.log('nooo blank wishlist');

    // $('.wishlist-menu-filled-class').css('display','block');
    // $('.wishlist-menu-blank-class').css('display','none');
   }
   
    
}
//-------wish list menu color change using this function 


//----------- Show product into wish list popup --------
function wish_list_menu_item_show(wishlist){
 
if (wishlist.length) {
             $('#no-pro-in-wish').css('display','none');
             $('.wish-list-btn-content').css('display','block');
              $('.wish_list_ul').css('display','block');
             
            restUrl += '?include='+wishlist.join(',');
            restUrl += '&per_page='+wishlist.length;

            $.ajax({
                dataType: 'json',
                url:restUrl
            })
            .done(function(response){
                $('.wish_list_ul').each(function(){
                    var $this = $(this);
                     var li_html='';         
                    
                    $.each(response,function(index,object){
                        // <a href="#" class="remove remove_from_wish_button" aria-label="" data-product_id="'+object.id+'" >×</a>
           li_html =li_html +'<li class="woocommerce-mini-wish-item mini_wish_item pop-li-'+object.id+'" data-product="'+object.id+'" id="pop-li-'+object.id+'"><a href="'+object.link+'"><span>'+object.image+'</span>'+object.title["rendered"]+'</a><span class="quantity">1 × <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">€</span>'+object.price+'</span></span></li>';
                   
                    });
                    // console.log(li_html);
                $this.html(li_html);
                });
            })
            .fail(function(response){
                alert(opt.noWishlist);
            })
            .always(function(response){
            });

        } else {
           
           $('#no-pro-in-wish').css('display','block');
           $('.wish_list_ul').css('display','none');
           $('.wish-list-btn-content').css('display','none');

        }
      
      
      //-----call this function for menu 
       // wishlist_menu(wishlist);
   
}
//----------- Show product into wish list popup --------


function remove_wish_list_menu_item_show(wishlist){  //---- its use for remove menu val

wishlist.splice(0,1);

if (wishlist.length) {
             $('#no-pro-in-wish').css('display','none');
             $('.wish-list-btn-content').css('display','block');
              $('.wish_list_ul').css('display','block');

           if (restUrl.indexOf("?") > 0) {
            var clean_uri = restUrl.substring(0, restUrl.indexOf("?"));
            // window.history.replaceState({}, document.title, clean_uri);
            }
              
                  if(typeof clean_uri =='undefined'){
                 restUrl += '?include='+wishlist.join(',');
                 restUrl += '&per_page='+wishlist.length;    
                 }else{
                 restUrl = clean_uri;
                 restUrl += '?include='+wishlist.join(',');
                 restUrl += '&per_page='+wishlist.length;    
                 }             

            
            $.ajax({
                dataType: 'json',
                url:restUrl
            })
            .done(function(response){
                $('.wish_list_ul').each(function(){
                    var $this = $(this);
                     var li_html='';         
                    
                    $.each(response,function(index,object){
                        // <a href="#" class="remove remove_from_wish_button" aria-label="" data-product_id="'+object.id+'" >×</a>
           li_html =li_html +'<li class="woocommerce-mini-wish-item mini_wish_item pop-li-'+object.id+'" data-product="'+object.id+'" id="pop-li-'+object.id+'"><a href="'+object.link+'"><span>'+object.image+'</span>'+object.title["rendered"]+'</a><span class="quantity">1 × <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">€</span>'+object.price+'</span></span></li>';
                   
                    });
                    // console.log(li_html);
                $this.html(li_html);
                });
            })
            .fail(function(response){
                alert(opt.noWishlist);
            })
            .always(function(response){
            });

        } else {
           
           $('#no-pro-in-wish').css('display','block');
           $('.wish_list_ul').css('display','none');
           $('.wish-list-btn-content').css('display','none');

        }



}



 

function add_wish_list_menu_item_show(wishlist,currentProduct){

if (wishlist.length) {
             $('#no-pro-in-wish').css('display','none');
             $('.wish-list-btn-content').css('display','block');
              $('.wish_list_ul').css('display','block');

            
            

            if (restUrl.indexOf("?") > 0) {
            var clean_uri = restUrl.substring(0, restUrl.indexOf("?"));
            // window.history.replaceState({}, document.title, clean_uri);
            }
              
                  if(typeof clean_uri =='undefined'){
                 restUrl += '?include='+currentProduct;
                 restUrl += '&per_page='+1;    
                 }else{
                 restUrl = clean_uri;
                 restUrl += '?include='+currentProduct;
                 restUrl += '&per_page='+1;    
                 }             
             

             console.log('new_url = '+ restUrl);
            
             // console.log(restUrl);
            $.ajax({
                dataType: 'json',
                url:restUrl
            })
            .done(function(response){
                // $('.wish_list_ul').each(function(){
                    // var $this = $(this);
                           
                    // console.log(response);
                    $.each(response,function(index,object){
                        // <a href="#" class="remove remove_from_wish_button" aria-label="" data-product_id="'+object.id+'" >×</a>
          $('.wish_list_ul').append('<li class="woocommerce-mini-wish-item mini_wish_item pop-li-'+object.id+'" data-product="'+object.id+'" id="pop-li-'+object.id+'"><a href="'+object.link+'"><span>'+object.image+'</span>'+object.title["rendered"]+'</a><span class="quantity">1 × <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">€</span>'+object.price+'</span></span></li>');
                   console.log(object.id);
                    });
                    // console.log(li_html);
          
                // });
             })
            .fail(function(response){
                alert(opt.noWishlist);
            })
            .always(function(response){
            });

        } else {
           
           $('#no-pro-in-wish').css('display','block');
           $('.wish_list_ul').css('display','none');
           $('.wish-list-btn-content').css('display','none');

        }





}


 $(document).on('click','.ajax_add_to_cart',function(){
   
   var str = $(this).attr('href');
   
   var n = str.search("=");
  var g = parseInt(n) + parseInt(1);
  
  var product_id = str.substring(g,100);


$('#wishlist-toggle-'+product_id).attr('data-cart','1000');

 });


})(jQuery);
